# Import utility packages
import pandas as pd
from datetime import datetime
import numpy as np
from sklearn.metrics import mean_absolute_error
from sklearn.linear_model import LinearRegression

# Read data into DataFrame
sphist = pd.read_csv("sphist.csv")

# Convert Date column to pandas `date` type
sphist["Date"] = pd.to_datetime(sphist["Date"])

# Example comparison
ex_comp = sphist["Date"] > datetime(year=2015, month=4, day=1)

# Sort the Date column in ascending order
sphist = sphist.sort_values("Date",ascending=True)
sphist.reset_index(inplace=True)

# Calculate the rolling 5-day-mean
rolling_5 = sphist["Close"].rolling(window=5,min_periods=5).mean()
rolling_5 = rolling_5.shift(periods=1)
sphist["day_5_mean"] = rolling_5
sphist["day_5_mean"] = sphist["day_5_mean"].fillna(0)

# Calculate the rolling 5-day-std
rolling_5 = sphist["Close"].rolling(window=5,min_periods=5).std()
rolling_5 = rolling_5.shift(periods=1)
sphist["day_5_std"] = rolling_5
sphist["day_5_std"] = sphist["day_5_std"].fillna(0)

# Calculate the rolling 30-day-mean
rolling_30 = sphist["Close"].rolling(window=30,min_periods=30).mean()
rolling_30 = rolling_30.shift(periods=1)
sphist["day_30_mean"] = rolling_30
sphist["day_30_mean"] = sphist["day_30_mean"].fillna(0)

# Calculate the rolling 30-day-std
rolling_30 = sphist["Close"].rolling(window=30,min_periods=30).std()
rolling_30 = rolling_30.shift(periods=1)
sphist["day_30_std"] = rolling_30
sphist["day_30_std"] = sphist["day_30_std"].fillna(0)

# Remove data prior to 1951-01-03
sphist = sphist[sphist["Date"] >= datetime(year=1951, month=1, day=3)]
sphist = sphist.dropna(axis=0)

# Split data in train and test set
train = sphist[sphist["Date"] < datetime(year=2013, month=1, day=1)]
test = sphist[sphist["Date"] >= datetime(year=2013, month=1, day=1)]

# Train a linear regression model
lr = LinearRegression()
features1 = ["day_5_mean","day_5_std","day_30_mean"]
features2 = ["day_5_mean","day_5_std","day_30_mean","day_30_std"]
target = "Close"
lr.fit(train[features1],train[target])

# Make predictions for the test set and calculate MAE (Mean Absolute Error)
predictions1 = lr.predict(test[features1])
MAE1 = mean_absolute_error(test[target],predictions1)
print(MAE1)
print()

# Feature2
lr.fit(train[features2],train[target])

# Make predictions for the test set and calculate MAE (Mean Absolute Error)
predictions2 = lr.predict(test[features2])
MAE2 = mean_absolute_error(test[target],predictions2)
print(MAE2)